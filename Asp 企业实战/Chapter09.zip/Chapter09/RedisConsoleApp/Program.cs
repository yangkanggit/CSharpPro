﻿using System;
using System.Collections.Generic;
//添加如下引用
using ServiceStack.Redis;
using System.Web.Script.Serialization;
using ServiceStack.Redis.Generic;

namespace RedisConsoleApp
{
    class Program
    {
        static RedisClient client = new RedisClient("127.0.0.1", 6379);

        #region 如果设置密码
        //static string host = "127.0.0.1";/*访问host地址*/
        //static string password = "2016@Test.88210_yujie";/*实例id:密码*/
        //static readonly RedisClient client = new RedisClient(host, 6379, password); 
        #endregion
        static IRedisTypedClient<InStoreReceipt> redis = client.As<InStoreReceipt>();

        static void Main(string[] args)
        {
            //StringTest();
            //HashTest();
            //QueueTest();
            //SetTest();
            SortedSetTest();
            SingleObjEnqueueTest();
            ListObjTest();
            ObjectTest();
        }
        /// <summary>
        /// 1. 字符串测试
        /// </summary>
        private static void StringTest()
        {
            Console.WriteLine("*******************字符串类型*********************");
            client.Set<string>("name", "zouqj");
            string userName = client.Get<string>("name");
            Console.WriteLine(userName);

            UserInfo userInfo = new UserInfo() { UserName = "张三", UserPwd = "123" };//(底层使用json序列化 )  
            client.Set<UserInfo>("userInfo", userInfo);
            UserInfo user = client.Get<UserInfo>("userInfo");
            Console.WriteLine(user.UserName);

            List<UserInfo> list = new List<UserInfo>() { new UserInfo() { UserName = "李四", UserPwd = "1234" }, new UserInfo() { UserName = "王五", UserPwd = "12345" } };
            client.Set<List<UserInfo>>("list", list);
            List<UserInfo> userInfoList = client.Get<List<UserInfo>>("list");

            foreach (UserInfo u in userInfoList)
            {
                Console.WriteLine(u.UserName);
            }
        }
        /// <summary>
        /// 2. Hash测试
        /// </summary>
        private static void HashTest()
        {
            Console.WriteLine("********************Hash*********************");
            client.SetEntryInHash("userInfoId", "name", "zhangsan");
            var lstKeys = client.GetHashKeys("userInfoId");
            lstKeys.ForEach(k => Console.WriteLine(k));
            var lstValues = client.GetHashValues("userInfoId");
            lstValues.ForEach(v => Console.WriteLine(v));
            client.Remove("userInfoId");
            Console.ReadKey();
        }
        /// <summary>
        /// 3. 队列和栈测试
        /// </summary>
        private static void QueueTest()
        {
            Console.WriteLine("*******************队列 先进先出********************");

            client.EnqueueItemOnList("test", "饶成龙");//入队。
            client.EnqueueItemOnList("test", "周文杰");
            long length = client.GetListCount("test");
            for (int i = 0; i < length; i++)
            {
                Console.WriteLine(client.DequeueItemFromList("test"));//出队.
            }
            Console.WriteLine("*********************栈 先进后出*****************");
            client.PushItemToList("name1", "邹琼俊");//入栈
            client.PushItemToList("name1", "周文杰");
            long length1 = client.GetListCount("name1");
            for (int i = 0; i < length1; i++)
            {
                Console.WriteLine(client.PopItemFromList("name1"));//出栈.
            }
            Console.ReadKey();
        }
        /// <summary>
        /// 4. Set 类型操作测试
        /// </summary>
        private static void SetTest()
        {
            //对Set类型进行操作  
            client.AddItemToSet("HighSchool", "卢沛");
            client.AddItemToSet("HighSchool", "邹琼俊");
            client.AddItemToSet("HighSchool", "周泱");
            client.AddItemToSet("HighSchool", "钟哲颖");
            client.AddItemToSet("HighSchool", "李薇");
            client.AddItemToSet("HighSchool", "刘自珍");
            client.AddItemToSet("HighSchool", "王鹏");
            client.AddItemToSet("HighSchool", "刘娇龙");
            client.AddItemToSet("HighSchool", "姜昆鹏");
            client.AddItemToSet("HighSchool", "吴燕妮");
            System.Collections.Generic.HashSet<string> hashset1 = client.GetAllItemsFromSet("HighSchool");
            Console.WriteLine("*******************邹琼俊和以下人员是高中同学***********************");
            ConsoleHashSetInfo(hashset1);
            //求并集  
            client.AddItemToSet("college", "邹琼俊");
            client.AddItemToSet("college", "卢沛");
            client.AddItemToSet("college", "熊平");
            client.AddItemToSet("college", "陈望");
            client.AddItemToSet("college", "王小敏");
            System.Collections.Generic.HashSet<string> hashset2 = client.GetUnionFromSets(new string[] { "HighSchool", "college" });
            Console.WriteLine("*******************邹琼俊和以下人员是高中同学或者大学同学***********************");

            ConsoleHashSetInfo(hashset2);
            Console.WriteLine("*******************邹琼俊和以下人员既是高中同学又大学同学***********************");
            //求交集  
            System.Collections.Generic.HashSet<string> hashset3 = client.GetIntersectFromSets(new string[] { "HighSchool", "college" });
            ConsoleHashSetInfo(hashset3);

            Console.WriteLine("*******************邹琼俊和以下人员只是高中同学***********************");
            //求差集.  
            System.Collections.Generic.HashSet<string> hashset4 = client.GetDifferencesFromSet("HighSchool", new string[] { "college" });
            ConsoleHashSetInfo(hashset4);
        }

        private static void ConsoleHashSetInfo(System.Collections.Generic.HashSet<string> hs)
        {
            foreach (string str in hs)
            {
                if (str == "邹琼俊")
                    continue;
                Console.WriteLine(str);
            }
        }
        /// <summary>
        /// 5. Sorted Set 测试
        /// </summary>
        private static void SortedSetTest()
        {
            client.AddItemToSortedSet("friend", "熊平",1);
            client.AddItemToSortedSet("friend", "陈望",3);
            client.AddItemToSortedSet("friend", "王小敏",5);
            client.AddItemToSortedSet("friend", "刘继豪",2);
            client.AddItemToSortedSet("friend", "侯亮",4);
            System.Collections.Generic.List<string> list = client.GetAllItemsFromSortedSet("friend");
            foreach (string str in list)
            {
                Console.WriteLine(str);
            }
        }
        /// <summary>
        /// 6. 单个对象队列测试
        /// </summary>
        private static void SingleObjEnqueueTest()
        {
            Console.WriteLine("******************实体对象队列操作********************");
            Student _stu = new Student { Name = "张三", Age = 21 };
            JavaScriptSerializer json = new JavaScriptSerializer();
            client.EnqueueItemOnList("stu", json.Serialize(_stu));
            _stu = json.Deserialize<Student>(client.DequeueItemFromList("stu"));
            Console.WriteLine(string.Format("姓名：{0},年龄{1}", _stu.Name, _stu.Age));
            Console.ReadKey();
        }

        /// <summary>
        /// 7. List对象测试
        /// </summary>
        public static void ListObjTest()
        {
            List<InStoreReceipt> list = new List<InStoreReceipt>() { new InStoreReceipt() { IdentityID = 1, ReceiptStatus = 1, ReceiptTime = DateTime.Now, ReceiptMessage = "test1" },
            new InStoreReceipt() { IdentityID = 2, ReceiptStatus = 1, ReceiptTime = DateTime.Now, ReceiptMessage = "test2" },new InStoreReceipt() { IdentityID = 3, ReceiptStatus = 1, ReceiptTime = DateTime.Now, ReceiptMessage = "test3" }};
            AddInStoreInfo(list);
            var rList = redis.GetAllItemsFromList(redis.Lists["InStoreReceiptInfoList"]);
            rList.ForEach(v => Console.WriteLine(v.IdentityID + "," + v.ReceiptTime + "," + v.ReceiptMessage));
            redis.RemoveAllFromList(redis.Lists["InStoreReceiptInfoList"]);
            Console.ReadKey();
        }

        /// <summary>
        /// 8. 实体对象测试
        /// </summary>
        private static void ObjectTest()
        {
            Console.WriteLine("**************实体对象，单个，列表操作*****************");
            UserInfo userInfo = new UserInfo() { UserName = "zhangsan", UserPwd = "1111" };//</span>(底层使用json序列化 )  
            client.Set<UserInfo>("userInfo", userInfo);
            UserInfo user = client.Get<UserInfo>("userInfo");
            Console.WriteLine(user.UserName);

            //List<UserInfo> list = new List<UserInfo>() { new UserInfo() { UserName = "lisi", UserPwd = "222" }, new UserInfo() { UserName = "wangwu", UserPwd = "123" } };
            //client.Set<List<UserInfo>>("list", list);
            List<UserInfo> userInfoList = client.Get<List<UserInfo>>("list");
            userInfoList.ForEach(u => Console.WriteLine(u.UserName));
            client.Remove("list");

            Console.ReadKey();
        }
        /// <summary>
        /// 添加需要回执的进仓单信息到Redis
        /// </summary>
        /// <param name="lstRInStore">进仓单回执信息列表</param>
        private static void AddInStoreInfo(List<InStoreReceipt> inStoreReceipt)
        {
            IRedisList<InStoreReceipt> rlstRInStore = redis.Lists["InStoreReceiptInfoList"];
            rlstRInStore.AddRange(inStoreReceipt);
        } 
    }
    public class UserInfo
    {
        public string UserName { get; set; }
        public string UserPwd { get; set; }
    }
    /// <summary>
    /// 进仓单回执信息（对应清关系统）
    /// </summary>
    public class InStoreReceipt
    {
        /// <summary>
        /// 主键ID
        /// </summary>
        public int IdentityID { get; set; }
        /// <summary>
        /// 回执状态
        /// </summary>
        public int ReceiptStatus { get; set; }
        /// <summary>
        /// 回执时间
        /// </summary>
        public DateTime ReceiptTime { get; set; }
        /// <summary>
        /// 回执信息
        /// </summary>
        public string ReceiptMessage { get; set; }
    }
    public class Student
    {
        /// <summary>
        /// 姓名
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 年龄
        /// </summary>
        public int Age { get; set; }
        /// <summary>
        /// 生日
        /// </summary>
        public DateTime BirthDate { get; set; }
    }

}
