﻿using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web.Mvc;
using WebApiClient.Models;

namespace WebApiClient.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            //客户端对象的创建与初始化
            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            //执行Get操作
            HttpResponseMessage response = client.GetAsync("http://localhost:16947/api/Products").Result;
            var list = response.Content.ReadAsAsync<List<Product>>().Result;
            ViewData.Model = list;

            return View();
        }
    }
}
