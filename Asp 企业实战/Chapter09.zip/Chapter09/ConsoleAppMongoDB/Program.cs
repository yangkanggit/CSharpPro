﻿using MongoDB;
using System;

namespace ConsoleAppMongoDB
{
    class Program
    {
        //集合名
        static string collectionName = "users";
        static void Main(string[] args)
        {
            //链接字符串
            string connectionString = "mongodb://127.0.0.1:27017";
            //数据库名
            string databaseName = "demo";

            //定义Mongo服务
            Mongo mongo = new Mongo(connectionString);
            //获取databaseName对应的数据库，不存在则自动创建
            MongoDatabase db = mongo.GetDatabase(databaseName) as MongoDatabase;
            //获取collectionName对应的集合，不存在则自动创建
            MongoCollection<Document> mongoCollection = db.GetCollection<Document>(collectionName) as MongoCollection<Document>;

            //链接数据库
            mongo.Connect();
            try
            {
                //定义一个文档对象，存入两个键值对
                Document doc = new Document();
                doc["ID"] = 1;
                doc["Msg"] = "Hello World!";

                //将这个文档对象插入集合
                mongoCollection.Insert(doc);
                //mongoCollection.Remove(doc);

                //在集合中查找键值对为ID=1的文档对象
                Document docFind = mongoCollection.FindOne(new Document { { "ID", 1 } });

                //输出查找到的文档对象中键“Msg”对应的值，并输出
                Console.WriteLine(Convert.ToString(docFind["Msg"]));

                Insert(db);
                Update(db);
                Query(db);
                Delete(db);
                Console.ReadLine();
            }
            finally
            {
                //关闭链接
                mongo.Disconnect();
            }
        }

        /// <summary>
        /// 添加数据
        /// </summary>
        static void Insert(MongoDatabase db)
        {
            var col = db.GetCollection<Users>(); //会自动创建一个名称为Users的集合，集合名称区分大小写
            //或者 
            //var col = db.GetCollection("Users");
            Users users = new Users();
            users = new Users { name = "邹玉杰", age = 28 };
            col.Insert(users);
            users = new Users { name="邹琼俊",age=27};
            col.Insert(users);
            users = new Users { name = "邹宇峰", age =2 };
            col.Insert(users);
        }
        /// <summary>
        /// 更新数据
        /// </summary>
        static void Update(MongoDatabase db)
        {
            var col = db.GetCollection<Users>(); 
            //查出Name值为xumingxiang的第一条记录
            Users users = col.FindOne(x => x.name == "邹琼俊");
            //或者 
            //Users users = col.FindOne(new Document { { "Name", "邹琼俊" } });
            if (users == null)
                return;
            users.age =26;
            col.Update(users, x => x.age == 27);
        }

        /// <summary>
        /// 删除数据
        /// </summary>
        static void Delete(MongoDatabase db)
        {
            var col = db.GetCollection<Users>();
            col.Remove(x => x.age == 28);
            col.Remove(x => x.age == 27);
            ////或者
            ////查出Name值为xumingxiang的第一条记录
            //Users users = col.FindOne(x => x.age == 27);
            //col.Remove(users);
        }

        /// <summary>
        /// 查询数据
        /// </summary>
        static void Query(MongoDatabase db)
        {
            var col = db.GetCollection<Users>(); 
            var query = new Document { { "Name", "邹琼俊" } };
            //查询指定查询条件的全部数据
            var result1 = col.Find(query);
            //查询指定查询条件的第一条数据
            var result2 = col.FindOne(query);
            //查询全部集合里的数据
            var result3 = col.FindAll();
        }
    }
    public class Users
    {
        public string name { get; set; }
        public int age { get; set; }
    }
}
