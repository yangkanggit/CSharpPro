﻿using System.ServiceModel;

namespace HelloService
{
    [ServiceContract(Namespace = "http://Microsoft.ServiceModel.Samples")]// 服务合约  
    public interface ICalculator
    {
        [OperationContract] // 操作合约  
        double Add(double n1, double n2);

        [OperationContract] // 操作合约  
        double Subtract(double n1, double n2);

        [OperationContract] // 操作合约  
        double Multiply(double n1, double n2);

        [OperationContract] // 操作合约  
        double Divide(double n1, double n2);
    }
}  

