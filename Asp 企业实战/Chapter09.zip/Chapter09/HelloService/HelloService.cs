﻿
namespace HelloService
{
    public class HelloService : IHelloService
    {
        public string SayHello(string name)
        {
            return "你好，我是：" + name;
        }
    }  
}
