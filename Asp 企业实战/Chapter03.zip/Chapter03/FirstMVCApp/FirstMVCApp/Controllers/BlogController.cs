﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FirstMVCApp.Controllers
{
    public class BlogController : Controller
    {
        /// <summary>
        /// Action方法，返回ActionResult
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            ViewBag.Message = "First ASP.NET MVC application.";//展现到视图中数据
            //~/Views/Home/Index.cshtml
            return View(); //展现指定的视图，当没有指定视图名称时，默认是指向根目录下Views文件夹中，子文件夹名称为当前控制器名称Home，视图名称和当前Action名称一样
        }
        public string Say()
        {
            return "Hello,World!";
        }
        public ActionResult ShowArticle()
        {
            return View("Article");
        }
    }
}
