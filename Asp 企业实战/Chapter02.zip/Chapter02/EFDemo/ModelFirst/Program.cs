﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModelFirst
{
    class Program
    {
        static void Main(string[] args)
        {
            //AddTestData();
            //SearchCusOrder();
            JoinSearchCusOrder();
        }
        /// <summary>
        /// 1、添加测试数据
        /// </summary>
        static void AddTestData()
        {
            using (ModelFirstModelContainer db = new ModelFirstModelContainer())
            {
                Customer _Customer = new Customer { Name = "楚留香", Age = 27, CompanyName = "大旗门", Telphone = "15243641131" };
                Order _Order1 = new Order { Amount = 15, CreateTime = DateTime.Now, OrderNO = "2016043001", CustomerID = _Customer.ID };
                Order _Order2 = new Order { Amount = 16, CreateTime = DateTime.Now, OrderNO = "2016043002", Customer = _Customer };
                Product _Product = new Product { ID = Guid.NewGuid(), Name = "牛栏1段", Price = 12, Weight = 80, Customer = new List<Customer>() { _Customer } };

                db.Customer.Add(_Customer);
                db.Product.Add(_Product);
                db.Order.Add(_Order1);
                db.Order.Add(_Order2);

                if (db.SaveChanges() > 0)
                {
                    Console.WriteLine("添加成功！");
                }
                else
                {
                    Console.WriteLine("添加失败！");
                }
            }
        }
        /// <summary>
        /// 2、	查询客户楚留香的所有订单信息
        /// </summary>
        static void SearchCusOrder()
        {
            using (ModelFirstModelContainer db = new ModelFirstModelContainer())
            {
                var _orderList = from o in db.Order where o.Customer.Name == "楚留香" select o;
                Console.WriteLine("客户楚留香的所以订单如下：");
                _orderList.ToList().ForEach(o=>Console.WriteLine(string.Format("订单号：{0}，订单金额：{1},订单创建时间：{2}",o.OrderNO,o.Amount,o.CreateTime)));
                Console.ReadKey();
            }
        }
        static void JoinSearchCusOrder()
        {
            using (ModelFirstModelContainer db = new ModelFirstModelContainer())
            {
                var _orderList = from c in db.Customer join o in db.Order on c.ID equals o.CustomerID where c.Name == "楚留香" select o;
                Console.WriteLine("客户楚留香的所以订单如下：");
                _orderList.ToList().ForEach(o => Console.WriteLine(string.Format("订单号：{0}，订单金额：{1},订单创建时间：{2}", o.OrderNO, o.Amount, o.CreateTime)));
                Console.ReadKey();
            }
        }
    }
}
