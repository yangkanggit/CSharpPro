﻿/****************************************************************************
* Copyright (c) 2016Microsoft All Rights Reserved.
* CLR版本： 4.0.30319.18052
*机器名称：ZOUYUJIE-PC
*公司名称：Microsoft
*命名空间：EFCRUD
*文件名：  Class
*版本号：  V1.0.0.0
*唯一标识：26d16858-1f97-4560-9a99-5a3ad2fe1cd4
*当前的用户域：ZOUYUJIE-PC
*创建人：  邹琼俊
*电子邮箱：zouqiongjun@kjy.com
*创建时间：2016/4/24 16:46:31

*描述：
*
*=====================================================================
*修改标记
*修改时间：2016/4/24 16:46:31
*修改人： Administrator
*版本号： V1.0.0.0
*描述：
*
*****************************************************************************/
using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace EFCRUD
{
    class Program
    {
        static void Main(string[] args)
        {
           //string msg=Add()>0?"创建成功":"创建失败";
           //Console.WriteLine(msg);
           QueryDelay1();
            //QueryDelay2();
            Console.ReadKey();
        }
        #region 新增 
        static int Add()
        {
            using (NorthwindEntities db = new NorthwindEntities())
            {
                Customers _Customers = new Customers
                {
                    CustomerID = "zouqj",
                    Address = "南山区新能源创新产业园",
                    City = "深圳",
                    Phone = "15243641131",
                    CompanyName = "深圳跨境翼电商商务有限公司",
                    ContactName = "邹琼俊"
                };
                //方法一
                //db.Customers.Add(_Customers);

                //方法二
                DbEntityEntry<Customers> entry = db.Entry<Customers>(_Customers);
                entry.State = System.Data.EntityState.Added;

                return db.SaveChanges();
            }
        }
        #endregion
        #region  简单查询和延迟加载 
        static void QueryDelay1()
        {
            using (NorthwindEntities db = new NorthwindEntities())
            {
                DbQuery<Customers> dbQuery = db.Customers.Where(u => u.ContactName == "邹琼俊").OrderBy(u => u.ContactName).Take(1)
    as DbQuery<Customers>;
                //获得延迟查询对象后，调用对象的获取方法，此时，【就会根据之前的条件】，生成sql语句，查询数据库了！
                Customers _Customers = dbQuery.FirstOrDefault();// 或者SingleOrDefault()
                Console.WriteLine(_Customers.ContactName);
            }
        }

        // 针对于外键实体的延迟(按需加载)
        // 对于外键属性而言，EF会在用到这个外键属性的时候才去查询对应的表。 
        static void QueryDelay2()
        {
            using (NorthwindEntities db = new NorthwindEntities())
            {
                IQueryable<Orders> _Orders = db.Orders.Where(a => a.CustomerID == "zouqj");//真实返回的 DbQuery 对象，以接口方式返回
                //此时只查询了订单表
                Orders order = _Orders.FirstOrDefault();
                //当访问订单对象里的外键实体时，EF会查询订单对应的用户表，查询到之后，将数据装入这个外键实体
                Console.WriteLine(order.Customers.ContactName);

                IQueryable<Orders> orderList = db.Orders;
                foreach (Orders o in orderList)
                {
                    Console.WriteLine(o.OrderID + ":ContactName=" + o.Customers.ContactName);
                }
            }
        }
        #endregion
        #region 根据条件排序和查询
        /// <summary>
        /// 根据条件排序和查询
        /// </summary>
        /// <typeparam name="TKey">排序字段类型</typeparam>
        /// <param name="whereLambda">查询条件 lambda表达式</param>
        /// <param name="orderLambda">排序条件 lambda表达式</param>
        /// <returns></returns>
        public List<Customers> GetListBy<TKey>(Expression<Func<Customers, bool>> whereLambda, Expression<Func<Customers, TKey>> orderLambda)
        {
            using (NorthwindEntities db = new NorthwindEntities())
            {
                return db.Customers.Where(whereLambda).OrderBy(orderLambda).ToList();
            }
        }
        #endregion
        #region 分页查询 
        /// <summary>
        /// 分页查询
        /// </summary>
        /// <param name="pageIndex">页码</param>
        /// <param name="pageSize">页容量</param>
        /// <param name="whereLambda">条件 lambda表达式</param>
        /// <param name="orderBy">排序 lambda表达式</param>
        /// <returns></returns>
        public List<Customers> GetPagedList<TKey>(int pageIndex, int pageSize, Expression<Func<Customers, bool>> whereLambda,
 Expression<Func<Customers, TKey>> orderBy)
        {
            using (NorthwindEntities db = new NorthwindEntities())
            {
                // 分页时一定注意： Skip 之前一定要 OrderBy
                return db.Customers.Where(whereLambda).OrderBy(orderBy).Skip((pageIndex - 1) * pageSize).Take(pageSize).ToList();
            }
        }
        #endregion
        #region 官方推荐的 修改方式（先查询，再修改）
        /// <summary>
        /// 官方推荐的 修改方式（先查询，再修改）
        /// </summary>
        static void Edit()
        {
            using (NorthwindEntities db = new NorthwindEntities())
            {
                //1.查询出一个 要修改的对象 -- 注意：此时返回的是一个Customers类的代理类对象（包装类对象）
                Customers _Customers = db.Customers.Where(u => u.CustomerID == "zouqj").FirstOrDefault();
                Console.WriteLine("修改前：" + _Customers.ContactName);
                //2.修改内容 -- 注意：此时其实操作的是代理类对象 的属性，这些属性，会将值设置给内部的 Customers对象对应的属性，同时标记此属性为已修改状态
                _Customers.ContactName = "邹玉杰";
                //3.重新保存到数据库 -- 注意：此时 ef上下文，会检查容器内部 所有的对象，找到标记为修改的对象，然后找到标记为修改的对象属性，生成对应的update语句执行！
                db.SaveChanges();
                Console.WriteLine("修改成功：");
                Console.WriteLine(_Customers.ContactName);
            }
        }
        #endregion

        #region 自己优化的修改方式（创建对象，直接修改）
        /// <summary>
        /// 自己优化的修改方式（创建对象，直接修改）
        /// </summary>
        static void Edit2()
        {
            //1.查询出一个 要修改的对象
            Customers _Customers = new Customers()
            {
                CustomerID = "zouqj",
                Address = "南山区新能源创新产业园",
                City = "深圳",
                Phone = "15243641131",
                CompanyName = "深圳跨境翼电商商务有限公司",
                ContactName = "邹玉杰"
            };
            using (NorthwindEntities db = new NorthwindEntities())
            {
                //2.将对象加入EF容器,并获取当前实体对象的状态管理对象
                DbEntityEntry<Customers> entry = db.Entry<Customers>(_Customers);
                //3.设置 该对象 为被修改过
                entry.State = System.Data.EntityState.Unchanged;
                //4.设置该对象的ContactName属性为修改状态，同时 entry.State 被修改为 Modified 状态
                entry.Property("ContactName").IsModified = true;

                //var u = db.Customers.Attach(_Customers);
                //u.ContactName = "郭富城";

                //3.重新保存到数据库 -- ef 上下文会根据 实体对象的 状态 ，根据 entry.State =Modified 的值生成对应的 update sql 语句
                db.SaveChanges();
                Console.WriteLine("修改成功：");
                Console.WriteLine(_Customers.ContactName);
            }
        }
        #endregion

        #region 删除 -void Delete()
        /// <summary>
        ///  删除
        /// </summary>
        static void Delete()
        {
            using (NorthwindEntities db = new NorthwindEntities())
            {
                //1.创建要删除的 对象
                Customers u = new Customers() { CustomerID = "zouqj" };
                //2.附加到 EF中
                db.Customers.Attach(u);
                //3.标记为删除 注意：此方法就是标记当前对象为删除状态 ！
                db.Customers.Remove(u);

                /*
                    也可以使用 Entry 来附加和 修改
                    DbEntityEntry<Customers> entry = db.Entry<Customers>(u);
                    entry.State = System.Data.EntityState.Deleted;
                 */

                //4.执行删除sql
                db.SaveChanges();
                Console.WriteLine("删除成功！");
            }
        }
        #endregion

        #region  批处理 -- 上下文 SaveChanges 方法的好处！
        /// <summary>
        /// 批处理 -- 上下文 SaveChanges 方法的好处！
        /// </summary>
        static void SaveBatched()
        {
            //1新增数据
            Customers _Customers = new Customers
            {
                CustomerID = "zouyujie",
                Address = "洛阳西街",
                City = "洛阳",
                Phone = "1314520",
                CompanyName = "微软",
                ContactName = "邹玉杰"
            };
            using (NorthwindEntities db = new NorthwindEntities())
            {
                db.Customers.Add(_Customers);

                //2新增第二个数据
                Customers _Customers2 = new Customers
                {
                    CustomerID = "zhaokuanying",
                    Address = "洛阳西街",
                    City = "洛阳",
                    Phone = "1314520",
                    CompanyName = "微软",
                    ContactName = "赵匡胤"
                };
                db.Customers.Add(_Customers2);

                //3修改数据
                Customers usr = new Customers() { CustomerID = "zhaomu", ContactName = "赵牧" };
                DbEntityEntry<Customers> entry = db.Entry<Customers>(usr);
                entry.State = System.Data.EntityState.Unchanged;
                entry.Property("ContactName").IsModified = true;

                //4删除数据
                Customers u = new Customers() { CustomerID = "zouyujie" };
                //附加到 EF中
                db.Customers.Attach(u);
                //标记为删除 注意：此方法就是标记当前对象为删除状态 ！
                db.Customers.Remove(u);

                db.SaveChanges();
                Console.WriteLine("批处理 完成~~~~~~~~~~~~！");
            }
        }
        #endregion

        #region  批处理 -- 一次新增 50条数据 -void BatcheAdd()
        /// <summary>
        ///  批处理 -- 一次新增 50条数据
        /// </summary>
        static void BatcheAdd()
        {
            using (NorthwindEntities db = new NorthwindEntities())
            {
                for (int i = 0; i < 50; i++)
                {
                    Customers _Customers = new Customers
                    {
                        CustomerID = "zou" + i,
                        Address = "洛阳西街",
                        City = "洛阳",
                        Phone = "1314520",
                        CompanyName = "微软",
                        ContactName = "邹玉杰" + i
                    };
                    db.Customers.Add(_Customers);
                }
                db.SaveChanges();
            }
        }
        #endregion
    }
}
