﻿using System;
using System.Collections.Generic;
using System.Data.Entity;

namespace MvcFirstCode.Models
{
    public class MvcFirstCodeContext:DbContext
    {
        /// <summary>
        /// 注意这里的name要和配置文件里面配置的上下文连接字符串名称一致
        /// </summary>
        public MvcFirstCodeContext() : base("name=MvcFirstCodeContext") { }
        public DbSet<Order> Order { get; set; }
        public DbSet<OrderDetail> OrderDetail { get; set; }
    }
}