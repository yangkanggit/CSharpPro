﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MvcFirstCode.Models
{
    public class OrderDetail
    {
        [Key]
        public int OrderDetailId { get; set; }
        /// <summary>
        /// 订单明细单价
        /// </summary>
        public decimal Price { get; set; }
        /// <summary>
        /// 订单明细数量
        /// </summary>
        public int Count { get; set; }
        /// <summary>
        /// 外键，如果属性名称和Order主键名称一样，默认会当成外键，可以不加ForeignKey特性
        /// </summary>
        [ForeignKey("OrderBy")]
        public int OrderId { get; set; }

        /// <summary>
        /// 导航属性
        /// </summary>
        public virtual Order OrderBy { get; set; }
    }
}