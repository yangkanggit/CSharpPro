﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace MvcFirstCode.Models
{
    public class Order
    {
        /// <summary>
        /// 属性名后面有Id，默认会当成主键，可以不用添加[Key]属性
        /// </summary>
        [Key]
        public int OrderId { get; set; }
        /// <summary>
        /// 订单号
        /// </summary>
        [StringLength(50)]
        public string OrderCode { get; set; }
        /// <summary>
        /// 订单金额
        /// </summary>
        public decimal OrderAmount { get; set; }
        /// <summary>
        /// 导航属性设置成virtual，可以实现延迟加载
        /// </summary>
        public virtual ICollection<OrderDetail> OrderDetail { get; set; }
    }
}