﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcFirstCode.Models;
using System.Runtime.Remoting.Messaging;

namespace MvcFirstCode.Controllers
{
    public class BaseController : Controller
    {
        //方式一
        public MvcFirstCodeContext db
        {
            get
            {  //从当前线程中获取 MvcFirstCodeContext对象
                MvcFirstCodeContext db = CallContext.GetData("DB") as MvcFirstCodeContext;
                if (db == null)
                {
                    db = new MvcFirstCodeContext();
                    CallContext.SetData("DB", db);
                }
                return db;
            }
        }
        //方式二
        public MvcFirstCodeContext DB2
        {
            get {
                MvcFirstCodeContext db = null;
                if (HttpContext.Items["db1"] == null)
                {
                    db = new MvcFirstCodeContext();
                    HttpContext.Items["db1"] = db;
                }
                else
                {
                    db = HttpContext.Items["db1"] as MvcFirstCodeContext;
                }
                return db;
            }
        }
    }
}
