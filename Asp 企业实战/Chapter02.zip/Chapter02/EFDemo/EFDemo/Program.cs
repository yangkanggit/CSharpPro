﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace EFDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            DemoSiteEntities entity = new DemoSiteEntities();
            T_Customer customer = new T_Customer { Address="东海五彩金轮",Age=27,UserName="楚留香"};
            entity.T_Customer.Add(customer); //这里只相当于构造sql语句
            entity.SaveChanges(); //这里才进行数据库操作，相当于按F5执行
        }
    }
}
