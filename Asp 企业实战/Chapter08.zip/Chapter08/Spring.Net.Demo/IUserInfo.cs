﻿
namespace Spring.Net.Demo
{
    public interface IUserInfo
    {
        string ShowMsg();
    }
}