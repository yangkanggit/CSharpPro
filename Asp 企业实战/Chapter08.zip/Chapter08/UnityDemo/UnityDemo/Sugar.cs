﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnityDemo
{
    /// <summary>
    /// 糖
    /// </summary>
   public class Sugar:IProduct
    {
       public string ClassName { get; set; }

       public void ShowInfo()
       {
           Console.WriteLine("糖：{0}", ClassName);
       }
    }
}
