﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnityDemo
{
    /// <summary>
    /// 牛奶
    /// </summary>
   public class Milk:IProduct
    {
       public string ClassName { get; set; }

        public void ShowInfo()
        {
           Console.WriteLine("牛奶：{0}", ClassName);
        }
    }
}
