﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnityDemo
{
    /// <summary>
    /// 商品
    /// </summary>
   public interface IProduct
    {
        string ClassName { get; set; }
        void ShowInfo();
    }
}
