﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcAppOptimization.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/
        [OutputCache(Duration=5,VaryByParam="none")]
        public ActionResult Index()
        {
            ViewBag.Now = DateTime.Now.ToString();
            Response.Cache.SetOmitVaryStar(true); //解决一个隐蔽的bug
            return View();
        }
        [OutputCache(Duration=5,VaryByParam="name")]
        public ActionResult GetName(string name)
        {
            ViewData["Name"] = name;
            Response.Cache.SetOmitVaryStar(true); //解决一个隐蔽的bug
            return View();
        }
    }
}
