﻿using Shop.Business;
using System;

namespace ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            CustomersBusiness customersBusiness = new CustomersBusiness();
            var result = customersBusiness.GetCustomerList(c => 1 == 1);
            foreach (var v in result)
            {
                Console.WriteLine(v.CompanyName);
            }
            Console.ReadLine();
        }
    }
}
