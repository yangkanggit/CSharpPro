﻿using System.Web.Mvc;

namespace AdminAreaController
{
    /// <summary>
    /// 区域注册类
    /// </summary>
    public class AdminAreaRegistration : AreaRegistration
    {
        /// <summary>
        /// 区域名称，很明显可以重写，默认名称就是我们新建区域时取得名称，在某个区域中控制器的Action方法加载视图时会作为路径的一部分，说白了就是路径中的一个子文件夹名称。
        /// </summary>
        public override string AreaName
        {
            get
            {
                return "Admin";
            }
        }
        /// <summary>
        /// 这里是进行路由注册，和我们之前看到的路由注册有一点不一样的地方是：在最前面添加了区域名称“Admin”，其它地方一模一样，用法也一样
        /// </summary>
        /// <param name="context"></param>
        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "Admin",
                "Admin/{controller}/{action}/{id}",
                new { action = "Index", id = UrlParameter.Optional },
                new string[1] { "AdminAreaController.Controllers" }
            );
        }
    }
}
