﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace MvcAppRouting
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            routes.MapRoute(
                name: "Default",// 1.路由名称
                url: "{controller}/{action}/{id}",// 2.带有参数的URL
                defaults: new { controller = "Home", action = "Index", id = UrlParameter.Optional }, // 3.参数默认值，(UrlParameter.Optional表示可选的意思)
                constraints: new { controller = @"Home", action =@"Index|Test"} //正则
            );
            //routes.MapRoute(
            //    "blog", // 路由名称
            //    "{controller}/{action}/{id}", // 带有参数的 URL
            //    new { controller = "Home", action = "Index", id = UrlParameter.Optional }
            //    ,// 参数默认值               
            //    new { controller =@"Home|Blog|About|Admin"},
            //    new[] { "MvcAppRouting" }
            //);
        }
    }
}