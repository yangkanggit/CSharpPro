﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcAppAjax.Models;

namespace MvcAppAjax.Controllers
{
    public class JsonController : Controller
    {
        //
        // GET: /Json/
        NorthwindEntities db = new NorthwindEntities();

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult CustomersList() //返回类型也可写 JsonResult
        {
            var dogList = db.Customers.Select(x => new { CustomerID = x.CustomerID, ContactName = x.ContactName, Phone = x.Phone }).ToList();
            return Json(dogList, JsonRequestBehavior.AllowGet);
        }

    }
}
