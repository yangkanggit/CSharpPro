﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcAppAjax.Filter;

namespace MvcAppAjax.Controllers
{
    public class FilterTestController : Controller
    {
        //
        // GET: /Test/
        [MyCustormFilter]
        [TestAuthorize]
        public ActionResult Index()
        {
            return View();
        }
        [TestHandleError]
        public ActionResult GetErr()
        {
            int a = 0;
            int b = 1 / a;
            return View();
        }
    }
}
