﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcAppAjax.Filter;
using MvcAppAjax.Models;
using Newtonsoft.Json;

namespace MvcAppAjax.Controllers
{
    [MyResultFilter]
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        [MyActionFilter]
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Index1()
        {
            return View();
        } 
        public PartialViewResult PartialViewTest()
        {
            ViewData["Msg"] = "Hello world!";
            return PartialView();
        }
        [HttpGet]
        public ActionResult ShowEmployeesList()
        {
            return View();
        }
        [HttpPost]
        public ActionResult GetEmployeesList()
        {
            using (NorthwindEntities db=new NorthwindEntities())
            {
                var list = db.Employees.Select(x => new { 
                FirstName=x.FirstName,LastName=x.LastName,City=x.City
                }).ToList();
                System.Web.Script.Serialization.JavaScriptSerializer jss = new System.Web.Script.Serialization.JavaScriptSerializer();
                return Content(jss.Serialize(list));
                //return Content(JsonConvert.SerializeObject(list));
              
            }
        }
        public ActionResult AjaxForm()
        {
            return View();
        }
        public ActionResult BaseInfo(string txtName)
        {
            using (NorthwindEntities db = new NorthwindEntities())
            {
                var result = db.Employees.Where(x => x.LastName == txtName).FirstOrDefault();
                return Content("姓："+result.FirstName+"名："+result.LastName);
            }
        }

    }
}
