﻿/****************************************************************************
* Copyright (c) 2016Microsoft All Rights Reserved.
* CLR版本： 4.0.30319.18052
*机器名称：ZOUYUJIE-PC
*公司名称：Microsoft
*命名空间：MvcAppAjax.Filter
*文件名：  TestAuthorizeAttribute
*版本号：  V1.0.0.0
*唯一标识：b8dc4b39-fee8-4f06-bd02-1b4c8114bf17
*当前的用户域：ZOUYUJIE-PC
*创建人：  邹琼俊
*电子邮箱：zouqiongjun@kjy.com
*创建时间：2016/5/15 16:02:29

*描述：
*
*=====================================================================
*修改标记
*修改时间：2016/5/15 16:02:29
*修改人： Administrator
*版本号： V1.0.0.0
*描述：
*
*****************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcAppAjax.Filter
{
    /// <summary>
    /// 授权过滤器 --在Action过滤器前执行
    /// </summary>
    public class TestAuthorizeAttribute : AuthorizeAttribute
    {
        public override void OnAuthorization(AuthorizationContext filterContext)
        {
            filterContext.HttpContext.Response.Write("OnAuthorization<br/>");
            //注释掉父类方法，因为父类里的 OnAuthorization 方法会调用asp.net的授权验证机制！
            //base.OnAuthorization(filterContext);
        }
    }
}