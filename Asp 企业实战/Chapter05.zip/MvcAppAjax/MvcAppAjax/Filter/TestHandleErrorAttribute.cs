﻿/****************************************************************************
* Copyright (c) 2016Microsoft All Rights Reserved.
* CLR版本： 4.0.30319.18052
*机器名称：ZOUYUJIE-PC
*公司名称：Microsoft
*命名空间：MvcAppAjax.Filter
*文件名：  TestHandleErrorAttribute
*版本号：  V1.0.0.0
*唯一标识：279db6b8-21d5-436f-9bd5-f809a3a9d550
*当前的用户域：ZOUYUJIE-PC
*创建人：  邹琼俊
*电子邮箱：zouqiongjun@kjy.com
*创建时间：2016/5/15 16:08:09

*描述：
*
*=====================================================================
*修改标记
*修改时间：2016/5/15 16:08:09
*修改人： Administrator
*版本号： V1.0.0.0
*描述：
*
*****************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcAppAjax.Filter
{
    /// <summary>
    /// 异常处理 过滤器
    /// </summary>
    public class TestHandleErrorAttribute : HandleErrorAttribute
    {
        public override void OnException(ExceptionContext filterContext)
        {
            //1.获取异常对象
            Exception ex = filterContext.Exception;
            //2.记录异常日志
            //3.重定向友好页面
            filterContext.Result = new RedirectResult("~/error.html");
            //4.标记异常已经处理完毕
            filterContext.ExceptionHandled = true;

            base.OnException(filterContext);
        }
    }
}