﻿using Quartz;
/****************************************************************************
 *Copyright (c) 2016 All Rights Reserved.
 *CLR版本： 4.0.30319.42000
 *机器名称：DESKTOP-V7CFIC3
 *公司名称：
 *命名空间：QuartzNet
 *文件名：  TotalJob
 *版本号：  V1.0.0.0
 *唯一标识：9f4cffa7-9c22-4619-a008-37b25db503b0
 *当前的用户域：DESKTOP-V7CFIC3
 *创建人：  zouqi
 *电子邮箱：zouyujie@126.com
 *创建时间：2016/7/9 14:59:43

 *描述：
 *
 *=====================================================================
 *修改标记
 *修改时间：2016/7/9 14:59:43
 *修改人： zouqi
 *版本号： V1.0.0.0
 *描述：
 *
 *****************************************************************************/

namespace QuartzNet
{
    public class TotalJob : IJob
    {
        /// <summary>
        /// 将明细表中的数据插入到汇总表中。
        /// </summary>
        /// <param name="context"></param>
        public void Execute(JobExecutionContext context)
        {
            KeyWordsTotalService bll = new KeyWordsTotalService();
            bll.DeleteAllKeyWordsRank();
            bll.InsertKeyWordsRank();
        }
    }
}
