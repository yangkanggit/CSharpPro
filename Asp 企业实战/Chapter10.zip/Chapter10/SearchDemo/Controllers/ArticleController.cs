﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SearchDemo.Models;
using SearchDemo.Common;

namespace SearchDemo.Controllers
{
    public class ArticleController : Controller
    {
        private SearchDemoContext db = new SearchDemoContext();

        //
        // GET: /ArticleController/

        public ActionResult Index()
        {
            //当操作的表存在时，则不进行创建如果不存在，则创建
            db.Database.CreateIfNotExists();
            return View(db.Article.ToList());
        }

        //
        // GET: /ArticleController/Details/5

        public ActionResult Details(string kw,int id = 0)
        {
            Article article = db.Article.Find(id);
            if (article == null)
            {
                return HttpNotFound();
            }
            if (!string.IsNullOrEmpty(kw))
            {
                List<string> lstkw = LuceneHelper.PanGuSplitWord(kw);
                var result = article.Content;
                foreach (var v in lstkw)
                {
                    result = result.Replace(v, "<span style='Color:Red'>" + v + "</span>");
                }
                article.Content = result;
            }
            return View(article);
        }

        //
        // GET: /ArticleController/Create

        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /ArticleController/Create

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult Create(Article article)
        {
            if (ModelState.IsValid)
            {
                article.CreateTime = DateTime.Now;
                db.Article.Add(article);
                db.SaveChanges();
                SearchIndexManager.GetInstance().AddQueue(article.ArticleId.ToString(), article.Title, article.Content, article.CreateTime);
                return RedirectToAction("Index","Article");
            }

            return View(article);
        }

        //
        // GET: /ArticleController/Edit/5

        public ActionResult Edit(int id = 0)
        {
            Article article = db.Article.Find(id);
            if (article == null)
            {
                return HttpNotFound();
            }
            return View(article);
        }

        //
        // POST: /ArticleController/Edit/5

        [HttpPost]
        public ActionResult Edit(Article article)
        {
            if (ModelState.IsValid)
            {
                db.Entry(article).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(article);
        }

        //
        // GET: /ArticleController/Delete/5

        public ActionResult Delete(int id = 0)
        {
            Article article = db.Article.Find(id);
            if (article == null)
            {
                return HttpNotFound();
            }
            return View(article);
        }

        //
        // POST: /ArticleController/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            Article article = db.Article.Find(id);
            db.Article.Remove(article);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}