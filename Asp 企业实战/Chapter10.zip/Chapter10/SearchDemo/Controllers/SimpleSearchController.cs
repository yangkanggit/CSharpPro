﻿using Lucene.Net.Analysis.PanGu;
using Lucene.Net.Documents;
using Lucene.Net.Index;
using Lucene.Net.Search;
using Lucene.Net.Store;
using SearchDemo.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Web.Mvc;

namespace SearchDemo.Controllers
{
    public class SimpleSearchController : Controller
    {
        string indexPath = @"D:\Study\Chapter10\lucenedir";//注意和磁盘上文件夹的大小写一致，否则会报错。  

        //表单中有多个Submit，单击每个Submit都会提交表单，但是只会将用户所单击的表单元素的value值提交到服务端。
        public ActionResult Index(string txtSearch, string btnSearch,string btnCreate)
        {
            List<SearchResult> list = null;
            if (!string.IsNullOrEmpty(btnSearch))//如果点击的是查询按钮
            {
                list=Search(txtSearch);
            }
            else if(!string.IsNullOrEmpty(btnCreate)) //如果点击的创建索引按钮
            {
                string msg = CreateIndex();
                ViewData["ShowInfo"] = string.IsNullOrEmpty(msg) ? "创建成功" : msg;
            }
            return View(list);
        }
        //查询
        private List<SearchResult> Search(string kw)
        {
            FSDirectory directory = FSDirectory.Open(new DirectoryInfo(indexPath), new NoLockFactory());
            IndexReader reader = IndexReader.Open(directory, true);
            IndexSearcher searcher = new IndexSearcher(reader);
            PhraseQuery query = new PhraseQuery();//查询条件
            query.Add(new Term("msg", kw));//where contains("msg",kw)
            //foreach (string word in kw.Split(' '))//先用空格，让用户去分词，空格分隔的就是词“诸葛亮 ”
            //{
            //    query.Add(new Term("msg", word));//contains("msg",word)
            //}
            query.SetSlop(100);//两个词的距离大于100（经验值）就不放入搜索结果，因为距离太远相关度就不高了
            TopScoreDocCollector collector = TopScoreDocCollector.create(1000, true);//盛放查询结果的容器
            searcher.Search(query, null, collector);//使用query这个查询条件进行搜索，搜索结果放入collector
            //collector.GetTotalHits()总的结果条数
            ScoreDoc[] docs = collector.TopDocs(0, collector.GetTotalHits()).scoreDocs;//从查询结果中取出第m条到第n条的数据

            List<SearchResult> list = new List<SearchResult>();
            string msg = string.Empty;

            for (int i = 0; i < docs.Length; i++)//遍历查询结果
            {
                int docId = docs[i].doc;//拿到文档的id。因为Document可能非常占内存（DataSet和DataReader的区别）
                //所以查询结果中只有id，具体内容需要二次查询
                Document doc = searcher.Doc(docId);//根据id查询内容。放进去的是Document，查出来的还是Document
                SearchResult result = new SearchResult();
                result.Id = Convert.ToInt32(doc.Get("id"));
                msg = doc.Get("msg");//只有 Field.Store.YES的字段才能用Get查出来
                result.Msg = msg.Length>200?msg.Substring(0,200)+"......":msg;
                result.Title = doc.Get("title");
                list.Add(result);
            }
            return list;
        }
        //创建索引库
        private string CreateIndex()
        {
            string msg = string.Empty;
            try
            {
                FSDirectory directory = FSDirectory.Open(new DirectoryInfo(indexPath), new NativeFSLockFactory());
                bool isUpdate = IndexReader.IndexExists(directory);//判断索引库是否存在
                if (isUpdate)
                {
                    //如果索引目录被锁定（比如索引过程中程序异常退出），则首先解锁
                    //Lucene.Net在写索引库之前会自动加锁，在close的时候会自动解锁
                    //不能多线程执行，只能处理意外被永远锁定的情况
                    if (IndexWriter.IsLocked(directory))
                    {
                        IndexWriter.Unlock(directory);//un-否定。强制解锁
                    }
                }
                IndexWriter writer = new IndexWriter(directory, new PanGuAnalyzer(), !isUpdate, Lucene.Net.Index.IndexWriter.MaxFieldLength.UNLIMITED);
                var files = System.IO.Directory.GetFiles(@"D:\Study\Chapter10\我的文章\", "*.txt");
                int i = 0;
                string title = string.Empty;

                foreach (var file in files)
                {
                    i++;
                    string txt =System.IO.File.ReadAllText(file, System.Text.Encoding.Default);
                    title = file.Substring(file.LastIndexOf(@"\") + 1, file.Length - file.LastIndexOf(@"\") - 1);
                    Document document = new Document();//一条Document相当于一条记录
                    document.Add(new Field("id", i.ToString(), Field.Store.YES, Field.Index.NOT_ANALYZED));
                    //每个Document可以有自己的属性（字段），所有字段名都是自定义的，值都是string类型
                    //Field.Store.YES不仅要对文章进行分词记录，也要保存原文，就不用去数据库里查一次了
                    //需要进行全文检索的字段加 Field.Index. ANALYZED
                    document.Add(new Field("title", title, Field.Store.YES, Field.Index.ANALYZED, Lucene.Net.Documents.Field.TermVector.WITH_POSITIONS_OFFSETS));
                    document.Add(new Field("msg", txt, Field.Store.YES, Field.Index.ANALYZED, Lucene.Net.Documents.Field.TermVector.WITH_POSITIONS_OFFSETS));
                    //防止重复索引，如果不存在则删除0条
                    writer.DeleteDocuments(new Term("id", i.ToString()));//防止存在的数据//delete from t where id=i
                    writer.AddDocument(document);//把文档写入索引库
                }
                writer.Close();
                directory.Close();//不要忘了Close，否则索引结果搜不到
            }
            catch (Exception ex)
            {
                msg = ex.Message;
            }
            finally
            {
            }
            return msg;
        }
    }
}
