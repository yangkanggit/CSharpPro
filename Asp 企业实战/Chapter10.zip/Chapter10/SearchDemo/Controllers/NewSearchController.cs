﻿using Lucene.Net.Documents;
using Lucene.Net.Index;
using Lucene.Net.Search;
using Lucene.Net.Store;
using SearchDemo.Common;
using SearchDemo.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Web.Mvc;

namespace SearchDemo.Controllers
{
    public class NewSearchController : Controller
    {
        //
        // GET: /NewSearch/
        string indexPath = System.Configuration.ConfigurationManager.AppSettings["lucenedir"];
        int showWords = 800;

        public ActionResult Index(string txtSearch)
        {
            List<SearchResult> list = null;
            if (!string.IsNullOrEmpty(txtSearch))//如果点击的是查询按钮
            {
                list = Search(txtSearch);
            }
            return View(list);
        }
        //查询
        private List<SearchResult> Search(string kw)
        {
            FSDirectory directory = FSDirectory.Open(new DirectoryInfo(indexPath), new NoLockFactory());
            IndexReader reader = IndexReader.Open(directory, true);
            IndexSearcher searcher = new IndexSearcher(reader);
            PhraseQuery query = new PhraseQuery();//查询条件
            List<string> lstkw = LuceneHelper.PanGuSplitWord(kw);//对用户输入的搜索条件进行拆分。
            foreach (string word in lstkw)//先用空格，让用户去分词，空格分隔的就是词“xx ”
            {
                query.Add(new Term("Content", word));//contains("Content",word)
            }
            query.SetSlop(100);//两个词的距离大于100（经验值）就不放入搜索结果，因为距离太远相关度就不高了
            TopScoreDocCollector collector = TopScoreDocCollector.create(1000, true);//盛放查询结果的容器
            searcher.Search(query, null, collector);//使用query这个查询条件进行搜索，搜索结果放入collector
            //collector.GetTotalHits()总的结果条数
            ScoreDoc[] docs = collector.TopDocs(0, collector.GetTotalHits()).scoreDocs;//从查询结果中取出第m条到第n条的数据

            List<SearchResult> list = new List<SearchResult>();
            string msg = string.Empty;

            for (int i = 0; i < docs.Length; i++)//遍历查询结果
            {
                int docId = docs[i].doc;//拿到文档的id，因为Document可能非常占内存（思考DataSet和DataReader的区别）
                //所以查询结果中只有id，具体内容需要二次查询
                Document doc = searcher.Doc(docId);//根据id查询内容。放进去的是Document，查出来的还是Document
                SearchResult result = new SearchResult();
                result.Id = Convert.ToInt32(doc.Get("Id"));
                msg = doc.Get("Content");//只有 Field.Store.YES的字段才能用Get查出来
                msg = msg.Length > showWords ? msg.Substring(0, showWords) + "......" : msg;
                result.Msg = LuceneHelper.CreateHightLight(kw, msg);//将搜索的关键字高亮显示。
                result.Title = doc.Get("Title");
                result.CreateTime = Convert.ToDateTime(doc.Get("CreateTime"));
                list.Add(result);
            }
            return list;
        }
    }
}
