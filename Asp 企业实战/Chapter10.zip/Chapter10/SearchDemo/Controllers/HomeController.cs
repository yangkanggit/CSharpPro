﻿using Lucene.Net.Analysis;
using Lucene.Net.Analysis.PanGu;
using Lucene.Net.Analysis.Standard;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace SearchDemo.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        #region 一元分词
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Index(string txtBody)
        {
            string strResult = AnalyzerResult(txtBody, new StandardAnalyzer());

            return Content(strResult);
        } 
        #endregion
        #region 二元分词
        public ActionResult TwoAnalyzer()
        {
            return View();
        }
        [HttpPost]
        public ActionResult TwoAnalyzer(string txtBody)
        {
            string strResult = AnalyzerResult(txtBody, new CJKAnalyzer());

            return Content(strResult);
        } 
        #endregion
        #region 盘古分词
        public ActionResult PanGuAnalyzer()
        {
            return View();
        }
        [HttpPost]
        public ActionResult PanGuAnalyzer(string txtBody)
        {
            string strResult = AnalyzerResult(txtBody, new PanGuAnalyzer());

            return Content(strResult);
        }
        #endregion

        private string AnalyzerResult(string txtBody, Analyzer analyzer)
        {
            TokenStream tokenStream = analyzer.TokenStream("", new StringReader(txtBody));
            Lucene.Net.Analysis.Token token = null;
            StringBuilder sb = new StringBuilder();

            while ((token = tokenStream.Next()) != null)
            {
                sb.Append(token.TermText() + "\r\n");
            }
            return sb.ToString();
        }
    }
}
