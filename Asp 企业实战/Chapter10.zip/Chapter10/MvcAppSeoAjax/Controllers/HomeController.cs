﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcAppSeoAjax.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ContentResult GetMsg(int id)
        {
            string strResult = string.Empty;
            switch (id)
            {
                case 1:
                    strResult = @"搜索引擎蜘蛛（Spider）：向网站发出Get请求，获得页面内容，分析页面中的超链接，  
进一步的向页面中的超链接发Get请求，获得链接的页面内容。";
                    break;
                case 2:
                    strResult = @"因为LinkButton是执行JavaScript向服务器发请求来进行Redirect，而蜘蛛不会执行JS，所以尽量不要用LinkButton。";
                    break;
                case 3:
                    strResult = @"SEO友好的AJAX：做一个简单的根据参数来获得1、2、3三个文章的AJAX效果";
                    break;
                default:
                    break;
            }
            return Content(strResult);
        }
    }
}
